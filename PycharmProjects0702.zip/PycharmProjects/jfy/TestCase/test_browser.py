#!/usr/bin/env python
# -*- coding:utf-8 -*-
import time


def test_start(driver):
    time.sleep(2)