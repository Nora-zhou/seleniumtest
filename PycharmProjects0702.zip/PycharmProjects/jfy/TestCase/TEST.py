import os
import time

from selenium import webdriver
driver = webdriver.Chrome()

driver.get('https://oablink.qq.com/b2bshop/index/industrySites/235676754772303872')
time.sleep(1)
driver.find_element_by_xpath('//*[@id="b2bShopApp"]/div/div[1]/div/div/div/div[2]/div/a[1]').click()
time.sleep(1)
driver.find_element_by_name('username').send_keys('colorful')
time.sleep(1)
driver.find_element_by_name('password').send_keys('123@qq')
time.sleep(1)
driver.find_element_by_xpath('/html/body/div/section/form/div/div[4]/div/button').click()