#!/usr/bin/env python
# -*- coding:utf-8 -*-
import pytest
from selenium import webdriver

@pytest.fixture(scope="session")
def driver():
    # 打开浏览器
    driver = webdriver.Chrome("../chrome_driver_v79/chromedriver.exe")
    # 窗口最大化
    driver.maximize_window()
    yield driver
    # 关闭浏览器
    driver.quit()
