#!/usr/bin/env python
# -*- coding:utf-8 -*-
# @Time    : 2020/5/31 5:50 下午
# @Author  : Amy
import os
import yaml


class GetEnvironmentParameter(object):

    def __init__(self):
        cur_path = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
        self.parameter_path = os.path.join(os.path.join(cur_path, 'config'), 'environment_parameter.yaml')
        if not os.path.exists(self.parameter_path): os.mknod(self.parameter_path)

    def environment_parameter(self, environment_name):
        """
        获取环境参数
        :param environment_name: 环境名称
        :return:
        """
        with open(self.parameter_path, 'r', encoding='utf-8') as f:
            parameter = yaml.load(f, Loader=yaml.FullLoader)
        return parameter[environment_name]