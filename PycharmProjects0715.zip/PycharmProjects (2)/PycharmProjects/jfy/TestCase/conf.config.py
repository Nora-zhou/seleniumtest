#!/usr/bin/env python
# -*- coding:utf-8 -*-
import os


WEB_DRIVER=os.path.join(os.path.dirname(__file__),"../chromedriver/chromedriver.exe")