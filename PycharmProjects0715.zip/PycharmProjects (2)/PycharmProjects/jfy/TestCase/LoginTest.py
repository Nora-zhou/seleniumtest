import pytest
from selenium import webdriver
import time
from TestCase.pageUtils import *


#@pytest.fixture(scope='function')
def test_loginpage():
    wb=webutils(browser='chrome')
    wb.driver.get("https://blink.qq.com/b2bshop/index/industrySites/174133321650266123")
    wb.getElement("class","sign-btn primary__color primary__link-hover sign-in cursor-pointer").click()
    wb.driver.switch_to_alert("")
    wb.getElement("name", "username").send_keys("lixiang")
    wb.getElement("name", "password").send_keys("123@qq")
    wb.getElement("class", "v-button v-button--primary v-button--medium").click()