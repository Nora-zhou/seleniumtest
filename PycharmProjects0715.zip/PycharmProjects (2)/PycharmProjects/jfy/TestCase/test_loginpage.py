import pytest
from selenium import webdriver
import time
from TestCase.pageUtils import *


def login():
    login_name="testSeller03"
    wb = webutils(browser='chrome')
    wb.driver.get("https://blink.qq.com/b2bshop/index/industrySites/174133321650266123")
    wb.driver.maximize_window()
    time.sleep(5)
    # 切换到iframe
    wb.driver.switch_to_frame("_QD_INVITE_IFRAME_ID_PREFIX_2852150878")
    wb.getElement("class", "btn-text").click()
    wb.driver.switch_to.default_content()
    wb.ExcuteJs(
        "document.getElementsByClassName(\"sign-btn primary__color primary__link-hover sign-in cursor-pointer\")[0].click()")

    # 切换到登录框
    wb.driver.switch_to_frame("SignIn-ZH_CN")
    wb.getElement("name", "username").send_keys(login_name)
    time.sleep(2)
    wb.getElement("name", "password").send_keys("123@qq")
    wb.ExcuteJs("document.getElementsByClassName(\"v-button v-button--primary v-button--medium\")[0].click()")
    time.sleep(5)
    wb.driver.switch_to_frame("tcaptcha_iframe")
    # 定位滑块
    block = wb.getElement("id", "tcaptcha_drag_thumb")
    action = ActionChains(wb.driver)
    action.click_and_hold(block).move_by_offset(210, 0).release().perform()
    wb.driver.switch_to.default_content()
    time.sleep(6)
    # assert login nane

    get_login_name=wb.driver.find_element_by_xpath("//*[@id='b2bShopApp']/div/div[1]/div/div/div/div[2]/div/div[1]/div/a").text
    print(get_login_name)
    assert get_login_name in login_name
    return wb


def test_baseinfo():
    wb = login()
    # 点击基本资料
    time.sleep(3)
    wb.ExcuteJs(
        "document.querySelector(\"#b2bShopApp > div > div:nth-child(1) > div > div > div > div.user > div > div.tb-userinfo-list > ul > li:nth-child(1) > a\").click()")
    time.sleep(3)
    wb.driver.close()


def test_account():
    wb = login()
    # 点击账户安全
    time.sleep(1)
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[1]/div/div/div/div[2]/div/div[1]/div/a").click()
    time.sleep(1)
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[1]/div/div/div/div[2]/div/div[1]/ul/li[2]/a").click()
    time.sleep(3)
    # wb.ExcuteJs("document.querySelector(\"#b2bShopApp > div > div:nth-child(1) > div > div > div > div.user > div > div.tb-userinfo-list > ul > li:nth-child(2) > a\").click()")
    wb.driver.close()


def test_logout():
    wb = login()
    time.sleep(1)
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[1]/div/div/div/div[2]/div/div[1]/div/a").click()
    time.sleep(1)
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[1]/div/div/div/div[2]/div/div[1]/ul/li[3]/a").click()
    time.sleep(3)


if __name__ == '__main__':
    login()
