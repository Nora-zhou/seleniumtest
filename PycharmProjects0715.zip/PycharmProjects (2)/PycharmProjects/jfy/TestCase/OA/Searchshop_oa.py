import time
from TestCase.OA.Loginpage_oa import login


def test_searchshop():
    wb = login()
    time.sleep(2)
    # 搜索店铺
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div/div[2]/div/div/div/div[3]/div/div[1]/div[1]").click()
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div/div[2]/div/div/div/div[3]/div/div[1]/div[1]/div[2]/div[3]").click()
    time.sleep(1.5)
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[2]/div/div/div/div[3]/div/div[1]/div[2]/input").send_keys(
        "blackpink")  # input shop name
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div/div[2]/div/div/div/div[3]/div/div[2]/input").click()  # click search button
    time.sleep(1)
    # 选择店铺
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div/div[3]/div/div[2]/div/div[4]/div/div/div/div[5]/div[1]/div[5]/div").click()  # enter shop
    time.sleep(1)
    # 选择商品
    wb.SwitchWindow_Two()
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div/div[3]/div/div/div[2]/div[4]/div/div/div/div/div[5]/div/div[5]/a").click()  # select goods
    time.sleep(2)
    # # add 需求清单
    # wb.SwitchWindow_Two()
    # wb.getElement("xpath",
    #               "//*[@id='b2bShopApp']/div/div[3]/div/div[3]/div[1]/div[1]/div/div/div/div/div[2]/div[2]/div[6]/div[2]/div[1]/div/div[1]").click()  # select 附图片tes
    # wb.getElement("class", "v-number-input--step__input core-input").send_keys("15")
    # wb.getElement("class", "btn-item shop-car primary__color primary__border primary__bg-hover").click()  # click 加入需求清单


def test_searchgoods():
    wb = login()
    time.sleep(2)
    # 搜索商品
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[2]/div/div/div/div[3]/div/div[1]/div[2]/input").send_keys(
        "123")  # input goods name
    time.sleep(1)
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div/div[2]/div/div/div/div[3]/div/div[2]/input").click()  # click search button
    time.sleep(1)
    # 选择商品
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div/div[3]/div/div[2]/div/div[4]/div/div/div/div/div[5]/div/div[5]/a/div[1]/div/img").click()  # enter shop
    time.sleep(3)
    return wb

def test_selectgoods():
    wb = login()
    time.sleep(2)
    # 搜索店铺
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div/div[2]/div/div/div/div[3]/div/div[1]/div[1]").click()
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div/div[2]/div/div/div/div[3]/div/div[1]/div[1]/div[2]/div[3]").click()
    time.sleep(1.5)
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[2]/div/div/div/div[3]/div/div[1]/div[2]/input").send_keys(
        "blackpink")  # input shop name
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div/div[2]/div/div/div/div[3]/div/div[2]/input").click()  # click search button
    time.sleep(1)
    # 选择店铺
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div/div[3]/div/div[2]/div/div[4]/div/div/div/div[5]/div[1]/div[5]/div").click()  # enter shop
    time.sleep(1)


def test_askprice():#点击询价
    wb = login()
    time.sleep(3)
    # 搜索店铺
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div/div[2]/div/div/div/div[3]/div/div[1]/div[1]").click()
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div/div[2]/div/div/div/div[3]/div/div[1]/div[1]/div[2]/div[3]").click()
    time.sleep(1.5)
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[2]/div/div/div/div[3]/div/div[1]/div[2]/input").send_keys(
        "blackpink")  # input shop name
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div/div[2]/div/div/div/div[3]/div/div[2]/input").click()  # click search button
    time.sleep(1)
    # 选择店铺
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div/div[3]/div/div[2]/div/div[4]/div/div/div/div[5]/div[1]/div[5]/div").click()  # enter shop
    time.sleep(1)
    # 选择商品
    wb.SwitchWindow_Two()
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div/div[3]/div/div/div[2]/div[4]/div/div/div/div/div[5]/div/div[5]/a").click()  # select goods

    wb.SwitchWindow_Two()
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div/div[3]/div/div[3]/div[1]/div[1]/div/div/div/div/div[2]/div[2]/div[5]/div[2]/div[2]/div").click()  # 选择容量
    #wb.getElement("xpath","//*[@id='b2bShopApp']/div/div[3]/div/div[3]/div[1]/div[1]/div/div/div/div/div[2]/div[2]/div[6]/div[2]/span[1]/div[1]/input").clear()
    time.sleep(2)
    wb.getElement("xpath","//*[@id='b2bShopApp']/div/div[3]/div/div[3]/div[1]/div[1]/div/div/div/div/div[2]/div[2]/div[6]/div[2]/span[1]/div[1]/input").send_keys("00")
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[3]/div/div[3]/div[1]/div[1]/div/div/div/div/div[2]/div[3]/div[2]").click()
    return wb

def test_askprice_detail():
    wb = test_askprice()
    # 上面代码是test_askprice
    time.sleep(2)
    wb.SwitchWindow_By_Url("https://oablink.qq.com/member/shoprfq/index/create?base=salesInformation")
    # 选择商品百科
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div[1]/div/div/div[2]/div/div[2]/div[1]/div/div/div/form/div/section[3]/div/div[2]/div[1]/div[14]/table/tbody/tr/td[3]/span/div/div[1]/div[2]/div/div").click()
    time.sleep(1)
    wb.getElement("xpath", "/html/body/div[80]/div/div/div[1]/ul/li[1]/div/div/a/div").click()
    # time.sleep(2)
    # wb.getElement("xpath",
    #               "//*[@id='b2bShopApp']/div[1]/div/div/div[2]/div/div[2]/div[1]/div/div/div/form/div/section[4]/div/div/div[1]/div/div[2]/div[2]/div[2]/a/label")
    time.sleep(3)
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div[1]/div/div/div[2]/div/div[2]/div[1]/div/div/div/form/div/section[8]/div[1]/button").click()

def test_request_list():
    wb = login()
    time.sleep(2)
    # 搜索店铺
    wb.getElement("xpath", "//*[@id='b2bShopApp']/aside/div[1]/div[1]/div").click()
    time.sleep(1)
    wb.getElement("xpath", "//*[@id='b2bShopApp']/aside/div[2]/div[3]/div/span").click()
    time.sleep(5)
    wb.SwitchWindow_Two()
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div[1]/div/div/div/div/div[2]/div[1]/div[2]/div/div[1]/div[2]/div[1]/div[2]/div[1]/div[9]/table/tbody[2]/tr/td[1]/span/span/label/span").click()
    time.sleep(1)
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div[1]/div/div/div/div/div[2]/div[1]/div[2]/div/div[1]/div[2]/div[2]/div[2]/div[1]/div[9]/table/tbody[2]/tr/td[5]/span/span/div/input").send_keys(
        "")
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div[1]/div/div/div/div/div[2]/div[1]/div[2]/div/div[1]/div[2]/div[2]/div[2]/div[1]/div[9]/table/tbody[2]/tr/td[5]/span/span/div/input").send_keys(
        "568")
    time.sleep(2)
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div[1]/div/div/div/div/div[2]/div[1]/div[2]/div/div[1]/div[2]/div[1]/div[2]/div[2]/div/div[2]").click()
    time.sleep(3)


def test_addaskprice():#从买家中心点【新增询价】0706
    wb = login()
    time.sleep(1)
    #点击买家中心
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[1]/div/div/div/div[3]/div[2]/div[1]/div/a").click()
    #点击询价信息
    time.sleep(1)
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[1]/div/div/div/div[3]/div[2]/div[1]/ul/li[1]/a").click()
    time.sleep(3)
    #点击【新建询价单】按钮
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div[1]/div/div/div[2]/div/div[2]/div[1]/div[2]/div/div[1]/div[1]/div[1]/div/span/span/button/span").click()
    time.sleep(3)
    #选择频道
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div[1]/div/div/div[2]/div/div[2]/div[1]/div/div/div/form/div/section[1]/div/div/div/div/div/div[2]/div[2]/div/div/input").click()
    time.sleep(1)
    wb.getElement("xpath",
                  "/html/body/div[56]/div/div/div[1]/ul/li/div/div/a/div/div[1]").click()
    time.sleep(1)
    # 填写商品名称
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div[1]/div/div/div[2]/div/div[2]/div[1]/div/div/div/form/div/section[2]/div/div[2]/div[1]/div[14]/table/tbody/tr/td[2]/span/div/div[1]/div[1]/input").send_keys("123")
    time.sleep(2)
    #选择商品百科
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div[1]/div/div/div[2]/div/div[2]/div[1]/div/div/div/form/div/section[2]/div/div[2]/div[1]/div[14]/table/tbody/tr/td[3]/span/div/div[1]/div[2]/div/div/input").click()
    time.sleep(2)
    #选择【橙汁】
    wb.getElement("xpath",
                 "/html/body/div[114]/div/div/div[1]/ul/li[2]/div/div/a/div").click()
    time.sleep(2)
    #点击【保存并发送】按钮
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div[1]/div/div/div[2]/div/div[2]/div[1]/div/div/div/form/div/section[7]/div[1]/button").click()


def test_OrderNow():#从需求清单页面点【立即下单】0706
    wb = login()
    time.sleep(2)
    # 点击右侧【需求清单】图标
    wb.getElement("xpath", "//*[@id='b2bShopApp']/aside/div[1]/div[1]/div").click()
    time.sleep(1)
    # 点击【去需求清单询价/订购】按钮
    wb.getElement("xpath", "//*[@id='b2bShopApp']/aside/div[2]/div[3]/div/span").click()
    time.sleep(5)
    wb.SwitchWindow_Two()
    time.sleep(2)
    # 点击【立即下单】按钮
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div[1]/div/div/div/div/div[2]/div[1]/div[2]/div/div[1]/div[2]/div[1]/div[2]/div[2]/div/div[2]").click()
    time.sleep(3)
    wb.SwitchWindow_Two()
    time.sleep(3)
    # 选择“不需要发票“
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div[1]/div/div/div[2]/div/div[2]/div[1]/div/div/div/form/div/section[8]/div/div/div[1]/div/div[2]/div/label[2]/span[1]/span").click()
    time.sleep(2)
    # 点击【保存】按钮
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div[1]/div/div/div[2]/div/div[2]/div[1]/div/div/div/form/div/section[9]/div[1]/button").click()
    time.sleep(3)

def test_askprice2():#从需求清单页面点【立即询价】0706
    wb = login()
    time.sleep(2)
    # 点击右侧【需求清单】图标
    wb.getElement("xpath", "//*[@id='b2bShopApp']/aside/div[1]/div[1]/div").click()
    time.sleep(1)
    # 点击【去需求清单询价/订购】按钮
    wb.getElement("xpath", "//*[@id='b2bShopApp']/aside/div[2]/div[3]/div/span").click()
    time.sleep(5)
    wb.SwitchWindow_Two()
    time.sleep(2)
    # 点击【立即询价】按钮
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div[1]/div/div/div/div/div[2]/div[1]/div[2]/div/div[1]/div[2]/div[2]/div[2]/div[2]/div/div[1]").click()
    time.sleep(3)
    wb.SwitchWindow_Two()
    time.sleep(3)
    # 点击【保存并发送】按钮
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div[1]/div/div/div[2]/div/div[2]/div[1]/div/div/div/form/div/section[8]/div[1]/button").click()
    time.sleep(3)