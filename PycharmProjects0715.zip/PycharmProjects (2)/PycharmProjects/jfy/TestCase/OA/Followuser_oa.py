import time
from TestCase.OA.Loginpage_oa import login

def test_user_follow():#关注用户0709
    wb = login()
    #点击搜索前的下拉框
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div/div[2]/div/div/div/div[3]/div/div[1]/div[1]").click()
    #点击下拉框【店铺】
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div/div[2]/div/div/div/div[3]/div/div[1]/div[1]/div[2]/div[3]").click()
    time.sleep(2)
    #搜索店铺
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[2]/div/div/div/div[3]/div/div[1]/div[2]/input").send_keys(
        "BlackPink")
    # 点击【搜索】按钮
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div/div[2]/div/div/div/div[3]/div/div[2]/input").click()
    time.sleep(1)
    # 选择店铺
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div/div[3]/div/div[2]/div/div[4]/div/div/div/div[5]/div[1]/div[5]/div").click()
    time.sleep(2)
    wb.SwitchWindow_Two()
    #关注客服
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div/div[3]/div/div/div[1]/div[2]/div/div/div[6]/div/span").click()
    time.sleep(2)
    #取消关注客服
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div/div[3]/div/div/div[1]/div[2]/div/div/div[6]/div/span").click()
    time.sleep(2)

def test_user_topping ():#用户置顶，取消置顶0709
    wb = login()
    time.sleep(1)
    # 点击买家中心
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[1]/div/div/div/div[3]/div[2]/div[1]/div/a").click()
    # 点击我的关注
    time.sleep(1)
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[1]/div/div/div/div[3]/div[2]/div[1]/ul/li[3]/a").click()
    time.sleep(1)
    # 点击关注用户
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div[1]/div/div/div[1]/div[4]/div[4]/a").click()
    time.sleep(2)
    #点击置顶
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div[1]/div/div/div[2]/div/div[2]/div[1]/div[2]/div/div[2]/div[1]/div/div[2]/div[2]").click()
    #点击取消置顶
    time.sleep(2)
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div[1]/div/div/div[2]/div/div[2]/div[1]/div[2]/div/div[2]/div[1]/div[1]/div[2]/div[2]").click()
    time.sleep(2)
