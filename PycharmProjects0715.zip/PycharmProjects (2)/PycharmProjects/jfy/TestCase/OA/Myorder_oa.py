import time
from TestCase.OA.Loginpage_oa import login
from selenium.webdriver.common.keys import Keys

def test_ViewOrder():#查看【我的订单】0708
    wb = login()
    time.sleep(2)
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[1]/div/div/div/div[3]/div[2]/div[1]/div/a").click()
    time.sleep(2)
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[1]/div/div/div/div[3]/div[2]/div[1]/ul/li[2]/a").click()
    time.sleep(3)



def test_Order_Search():#搜索订单0708
    wb = login()
    time.sleep(2)
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[1]/div/div/div/div[3]/div[2]/div[1]/div/a").click()
    time.sleep(2)
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[1]/div/div/div/div[3]/div[2]/div[1]/ul/li[2]/a").click()
    time.sleep(3)
    #搜索卖家企业抬头
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div[1]/div/div/div[2]/div/div[2]/div[1]/div[2]/div/div[1]/div[1]/div[2]/div/div/input").send_keys("colorful")
    time.sleep(2)
    #清空搜索内容
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div[1]/div/div/div[2]/div/div[2]/div[1]/div[2]/div/div[1]/div[1]/div[2]/div/div/input").send_keys(
        Keys.CONTROL, 'a')
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div[1]/div/div/div[2]/div/div[2]/div[1]/div[2]/div/div[1]/div[1]/div[2]/div/div/input").send_keys(
        Keys.BACKSPACE)
    time.sleep(2)
    #搜索订单编号
    wb.getElement("xpath",
         "//*[@id='b2bShopApp']/div[1]/div/div/div[2]/div/div[2]/div[1]/div[2]/div/div[1]/div[1]/div[2]/div/div/input").send_keys(
        "4465")


def test_Order_Cancel():#取消订单0708
    wb = login()
    time.sleep(2)
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[1]/div/div/div/div[3]/div[2]/div[1]/div/a").click()
    time.sleep(2)
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[1]/div/div/div/div[3]/div[2]/div[1]/ul/li[2]/a").click()
    time.sleep(3)
    # 搜索订单编号
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div[1]/div/div/div[2]/div/div[2]/div[1]/div[2]/div/div[1]/div[1]/div[2]/div/div/input").send_keys(
        "5904")
    time.sleep(2)
    #点击【取消订单】按钮
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div[1]/div/div/div[2]/div/div[2]/div[1]/div[2]/div/div[2]/div[12]/table[2]/tbody/tr/td[7]/span/div/span/span[2]/a/span").click()
    time.sleep(2)
    #填写取消原因
    wb.getElement("xpath",
                  "/html/body/div[9]/div[2]/div/div[1]/div/div[2]/input").send_keys(
        "数量选错")
    #点击【取消按钮】
    wb.ExcuteJs("document.getElementsByClassName(\"v-button v-button--default v-button--medium b-button__action\")[0].click()")
    time.sleep(2)


def test_Order_Chargeback():#申请退单0708
    wb = login()
    time.sleep(2)
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[1]/div/div/div/div[3]/div[2]/div[1]/div/a").click()
    time.sleep(2)
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[1]/div/div/div/div[3]/div[2]/div[1]/ul/li[2]/a").click()
    time.sleep(3)
    # 搜索订单编号
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div[1]/div/div/div[2]/div/div[2]/div[1]/div[2]/div/div[1]/div[1]/div[2]/div/div/input").send_keys(
        "4465")
    time.sleep(2)
    # 点击【申请退单】按钮
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div[1]/div/div/div[2]/div/div[2]/div[1]/div[2]/div/div[2]/div[12]/table[2]/tbody/tr/td[7]/span/div/span[2]/span[2]/a/span").click()
    time.sleep(2)
    #输入退单原因
    wb.getElement("xpath",
                  "/html/body/div[12]/div[2]/div/form/div/div[1]/div/input").send_keys(
        "质量问题")
    time.sleep(2)
    wb.ExcuteJs("document.getElementsByClassName(\"v-button v-button--default v-button--medium b-button__action\")[0].click()")
    time.sleep(2)


