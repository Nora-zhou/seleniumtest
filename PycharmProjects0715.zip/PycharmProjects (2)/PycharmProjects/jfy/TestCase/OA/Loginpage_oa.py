import pytest
from selenium import webdriver
import time
from TestCase.pageUtils import *


def login():
    wb = webutils(browser='chrome')
    wb.driver.get("https://oablink.qq.com/b2bshop/index/industrySites/235676754772303872")
    wb.driver.maximize_window()
    time.sleep(5)
    #切换到iframe
    #wb.driver.switch_to_frame("_QD_INVITE_IFRAME_ID_PREFIX_2852150878")
    #wb.getElement("class","btn-text").click()
    #wb.driver.switch_to.default_content()
    wb.ExcuteJs("document.getElementsByClassName(\"sign-btn primary__color primary__link-hover sign-in cursor-pointer\")[0].click()")

    #切换到登录框
    wb.driver.switch_to_frame("SignIn-ZH_CN")
    wb.getElement("name","username").send_keys("colorful")
    time.sleep(3)
    wb.getElement("name", "password").send_keys("123@qq")
    wb.ExcuteJs("document.getElementsByClassName(\"v-button v-button--primary v-button--medium\")[0].click()")
    time.sleep(5)
    wb.driver.switch_to_frame("tcaptcha_iframe")
    #定位滑块
    block=wb.getElement("id","tcaptcha_drag_thumb")
    action = ActionChains(wb.driver)
    action.click_and_hold(block).move_by_offset(210, 0).release().perform()
    wb.driver.switch_to.default_content()
    time.sleep(5)
    #关闭专属推荐
    wb.ExcuteJs("document.getElementsByClassName(\"common-button__box mpsi-button common-button__box--default primary__link-hover primary__border-hover\")[0].click()")
    time.sleep(3)
    return wb

def test_baseinfo():
    wb = login()
    # 点击基本资料
    time.sleep(3)
    wb.ExcuteJs(
        "document.querySelector(\"#b2bShopApp > div > div:nth-child(1) > div > div > div > div.user > div > div.tb-userinfo-list > ul > li:nth-child(1) > a\").click()")
    time.sleep(3)
    wb.driver.close()


def test_account():
    wb = login()
    # 点击账户安全
    time.sleep(1)
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[1]/div/div/div/div[2]/div/div[1]/div/a").click()
    time.sleep(1)
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[1]/div/div/div/div[2]/div/div[1]/ul/li[2]/a").click()
    time.sleep(3)
    # wb.ExcuteJs("document.querySelector(\"#b2bShopApp > div > div:nth-child(1) > div > div > div > div.user > div > div.tb-userinfo-list > ul > li:nth-child(2) > a\").click()")
    wb.driver.close()


def test_logout():
    wb = login()
    time.sleep(1)
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[1]/div/div/div/div[2]/div/div[1]/div/a").click()
    time.sleep(1)
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[1]/div/div/div/div[2]/div/div[1]/ul/li[3]/a").click()
    time.sleep(3)







if __name__ == '__main__':
    login()
    pytest.main(['--html=report/test.html'])