#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2020/7/13 17:30
# @Author  : Colorful.Jiang
import time
from TestCase.OA.Loginpage_oa import login
def buyer_account_check():# 买家中心-账号管理--查看
    wb = login()
    time.sleep(1)
    # 点击买家中心
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[1]/div/div/div/div[3]/div[2]/div[1]/div/a").click()
    # 点击我的关注
    time.sleep(1)
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[1]/div/div/div/div[3]/div[2]/div[1]/ul/li[3]/a").click()
    time.sleep(1)
    # 点击账号管理
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div[1]/div/div/div[1]/div[6]/div[3]/a").click()
    time.sleep(2)

def buyer_account_search():# 买家中心-账号管理--查看
    wb = login()
    time.sleep(1)
    # 点击买家中心
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[1]/div/div/div/div[3]/div[2]/div[1]/div/a").click()
    # 点击我的关注
    time.sleep(1)
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[1]/div/div/div/div[3]/div[2]/div[1]/ul/li[3]/a").click()
    time.sleep(1)
    # 点击账号管理
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div[1]/div/div/div[1]/div[6]/div[3]/a").click()
    time.sleep(2)
    # 搜索
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div[1]/div/div/div[2]/div/div[2]/div[1]/div[2]/div/div[1]/div/div[2]/div/div/input").send_keys("j")
    time.sleep(2)



def seller_account_check():# 卖家中心-账号管理--查看
    wb = login()
    time.sleep(1)
    # 点击卖家中心
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[1]/div/div/div/div[3]/div[2]/div[2]/div/a").click()
    # 点击店铺信息
    time.sleep(1)
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[1]/div/div/div/div[3]/div[2]/div[2]/ul/li[3]/a").click()
    time.sleep(1)
    # 点击账号管理
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div[1]/div/div/div[1]/div[7]/div[3]/a").click()
    time.sleep(2)

def seller_account_search():# 卖家中心-账号管理--搜索
    wb = login()
    time.sleep(1)
    # 点击卖家中心
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[1]/div/div/div/div[3]/div[2]/div[2]/div/a").click()
    # 点击店铺信息
    time.sleep(1)
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[1]/div/div/div/div[3]/div[2]/div[2]/ul/li[3]/a").click()
    time.sleep(1)
    # 点击账号管理
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div[1]/div/div/div[1]/div[7]/div[3]/a").click()
    time.sleep(2)
    # 搜索
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div[1]/div/div/div[2]/div/div[2]/div[1]/div[2]/div/div[1]/div/div[2]/div/div/input").send_keys("j")
    time.sleep(2)