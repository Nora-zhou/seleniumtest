#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2020/7/14 16:12
# @Author  : Colorful.Jiang
import time
from TestCase.OA.Loginpage_oa import login

def BrandSearch():# 品牌馆-字母检索
    wb = login()
    time.sleep(1)
    # 点击品牌馆
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[2]/div/div/div/div[5]/div/div[4]/span/a").click()
    time.sleep(1)
    # 点击字母检索“B”
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[3]/div/div[2]/div/div[1]/div/div/span[5]").click()
    time.sleep(1)

def Brand_EnterShop():#品牌馆-进入店铺
    wb = login()
    time.sleep(1)
    # 点击品牌馆
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[2]/div/div/div/div[5]/div/div[4]/span/a").click()
    time.sleep(1)
    # 点击字母检索“B”
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[3]/div/div[2]/div/div[1]/div/div/span[5]").click()
    time.sleep(1)
    # 进入店铺
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[3]/div/div[2]/div/div[4]/div/div/div/div[5]/div/div[5]/div/div[4]/a").click()
    time.sleep(1)

def Brand_CheckProduct():#品牌馆-查看商品
    wb = login()
    time.sleep(1)
    # 点击品牌馆
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[2]/div/div/div/div[5]/div/div[4]/span/a").click()
    time.sleep(1)
    # 点击字母检索“B”
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[3]/div/div[2]/div/div[1]/div/div/span[5]").click()
    time.sleep(1)
    # 点击商品
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[3]/div/div[2]/div/div[4]/div/div/div/div[5]/div/div[5]/div/div/div[5]/div[2]/div[5]/a/div[1]/div/svg").click()
    time.sleep(1)


