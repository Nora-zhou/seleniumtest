#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2020/7/13 15:33
# @Author  : Colorful.Jiang

import time
from TestCase.OA.Loginpage_oa import login
from selenium.webdriver.common.keys import Keys

def test_invoice_check():# 发票抬头--查看
    wb = login()
    time.sleep(1)
    # 点击买家中心
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[1]/div/div/div/div[3]/div[2]/div[1]/div/a").click()
    # 点击我的关注
    time.sleep(1)
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[1]/div/div/div/div[3]/div[2]/div[1]/ul/li[3]/a").click()
    time.sleep(1)
    # 点击发票抬头
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div[1]/div/div/div[1]/div[6]/div[4]/a").click()
    time.sleep(2)

def test_invoice_add():#发票抬头—新增
    wb = login()
    time.sleep(1)
    # 点击买家中心
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[1]/div/div/div/div[3]/div[2]/div[1]/div/a").click()
    # 点击我的关注
    time.sleep(1)
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[1]/div/div/div/div[3]/div[2]/div[1]/ul/li[3]/a").click()
    time.sleep(1)
    # 点击发票抬头
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div[1]/div/div/div[1]/div[6]/div[4]/a").click()
    time.sleep(2)
    # 点击【新建】按钮
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div[1]/div/div/div[2]/div/div[2]/div[1]/div[2]/div/div[1]/div[1]/div[1]/div/span/span/button/span").click()
    time.sleep(2)
    # 填写发票抬头
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div[1]/div/div/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div/div/form/div/section[1]/div/div/div[3]/div/div[2]/div/input").send_keys("Colorful发票")
    time.sleep(2)
    # 填写纳税人识别号
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div[1]/div/div/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div/div/form/div/section[1]/div/div/div[4]/div/div[2]/div/input").send_keys(
        "534534444434455433")
    time.sleep(2)
    # 点击【保存】按钮
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div[1]/div/div/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div/div/form/div/section[2]/div[1]/button").click()
    time.sleep(2)

def test_invoice_revise():#发票抬头-修改-保存
    wb = login()
    time.sleep(1)
    # 点击买家中心
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[1]/div/div/div/div[3]/div[2]/div[1]/div/a").click()
    # 点击我的关注
    time.sleep(1)
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[1]/div/div/div/div[3]/div[2]/div[1]/ul/li[3]/a").click()
    time.sleep(1)
    # 点击发票抬头
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div[1]/div/div/div[1]/div[6]/div[4]/a").click()
    time.sleep(2)
    # 点击【修改】按钮
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div[1]/div/div/div[2]/div/div[2]/div[1]/div[2]/div/div[2]/div[10]/table/tbody/tr[1]/td[6]/span/div/span[1]/span/a/span").click()
    time.sleep(2)
    # 清空纳税人识别号
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div[1]/div/div/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div/div/form/div/section[1]/div/div/div[4]/div/div[2]/div/input").send_keys(
        Keys.CONTROL, 'a')
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div[1]/div/div/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div/div/form/div/section[1]/div/div/div[4]/div/div[2]/div/input").send_keys(
        Keys.BACKSPACE)
    # 修改纳税人识别号
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div[1]/div/div/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div/div/form/div/section[1]/div/div/div[4]/div/div[2]/div/input").send_keys(
        "53453444443445775")
    time.sleep(2)
    # 点击【保存】按钮
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div[1]/div/div/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div/div/form/div/section[2]/div[1]/button").click()
    time.sleep(2)

