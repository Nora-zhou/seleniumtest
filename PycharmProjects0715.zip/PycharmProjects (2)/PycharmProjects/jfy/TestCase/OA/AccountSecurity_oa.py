#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2020/7/13 17:59
# @Author  : Colorful.Jiang
import time
from TestCase.OA.Loginpage_oa import login
def account_ChangePassword():# 买家中心-账号安全--修改密码
    wb = login()
    time.sleep(1)
    # 点击买家中心
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[1]/div/div/div/div[3]/div[2]/div[1]/div/a").click()
    # 点击我的关注
    time.sleep(1)
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[1]/div/div/div/div[3]/div[2]/div[1]/ul/li[3]/a").click()
    time.sleep(1)
    # 点击账号安全
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div[1]/div/div/div[1]/div[5]/div[3]/a").click()
    time.sleep(2)
    # 点击修改密码
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div[1]/div/div/div[2]/div/div[2]/div[1]/div/div/div/form/div/section[2]/div/div/div[3]/div/div/div[2]/span[2]").click()
    time.sleep(2)
    # 输入当前密码
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div[1]/div/div/div[2]/div/div[2]/div[1]/div/div/div/form/div/section[2]/div/div/div[3]/div/div/div[2]/div/div/div[2]/form/div[1]/div[1]/div[2]/div[1]/input").send_keys("123@qq")
    time.sleep(2)
    # 输入登录密码
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div[1]/div/div/div[2]/div/div[2]/div[1]/div/div/div/form/div/section[2]/div/div/div[3]/div/div/div[2]/div/div/div[2]/form/div[1]/div[2]/div[1]/div[2]/div[1]/input").send_keys(
        "123@qqq")
    time.sleep(2)
    # 输入确认密码
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div[1]/div/div/div[2]/div/div[2]/div[1]/div/div/div/form/div/section[2]/div/div/div[3]/div/div/div[2]/div/div/div[2]/form/div[1]/div[3]/div[2]/div[1]/input").send_keys(
        "123@qqq")
    time.sleep(2)
    # 点击【取消】
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div[1]/div/div/div[2]/div/div[2]/div[1]/div/div/div/form/div/section[2]/div/div/div[3]/div/div/div[2]/div/div/div[2]/form/div[2]/button[2]").click()
    time.sleep(2)

def account_Unbund_phone():# 买家中心-账号安全--手机号解绑
    wb = login()
    time.sleep(1)
    # 点击买家中心
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[1]/div/div/div/div[3]/div[2]/div[1]/div/a").click()
    # 点击我的关注
    time.sleep(1)
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[1]/div/div/div/div[3]/div[2]/div[1]/ul/li[3]/a").click()
    time.sleep(1)
    # 点击账号安全
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div[1]/div/div/div[1]/div[5]/div[3]/a").click()
    time.sleep(2)
    # 点击手机号解绑
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div[1]/div/div/div[2]/div/div[2]/div[1]/div/div/div/form/div/section[3]/div/div[3]/div[2]/div[3]/span[1]").click()
    time.sleep(2)
    # 点击【取消】
    wb.getElement("xpath", "/html/body/div[19]/div[3]/button[2]/span").click()
