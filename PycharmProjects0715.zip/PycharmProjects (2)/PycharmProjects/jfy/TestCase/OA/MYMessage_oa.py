#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2020/7/14 14:40
# @Author  : Colorful.Jiang
import time
from TestCase.OA.Loginpage_oa import login

def account_DeleteMessage():# 买家中心-我的消息-删除
    wb = login()
    time.sleep(1)
    # 点击买家中心
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[1]/div/div/div/div[3]/div[2]/div[1]/div/a").click()
    # 点击我的关注
    time.sleep(1)
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[1]/div/div/div/div[3]/div[2]/div[1]/ul/li[3]/a").click()
    time.sleep(1)
    # 点击账我的消息
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div[1]/div/div/div[1]/div[5]/div[4]/a").click()
    time.sleep(2)
    # 点击删除
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div[1]/div/div/div[2]/div/div[2]/div[1]/div[2]/div/div[2]/div[14]/table[2]/tbody/tr[6]/td[9]/span/div/span/span[2]/a/span").click()
    time.sleep(2)
    # 点击取消
    wb.getElement("xpath", "/html/body/div[14]/div[2]/div/div[2]/button[2]").click()
    time.sleep(2)

def account_MarkRead():# 买家中心-我的消息-标记已读
    wb = login()
    time.sleep(1)
    # 点击买家中心
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[1]/div/div/div/div[3]/div[2]/div[1]/div/a").click()
    # 点击我的关注
    time.sleep(1)
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[1]/div/div/div/div[3]/div[2]/div[1]/ul/li[3]/a").click()
    time.sleep(1)
    # 点击账我的消息
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div[1]/div/div/div[1]/div[5]/div[4]/a").click()
    time.sleep(2)
    # 标记已读
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div[1]/div/div/div[2]/div/div[2]/div[1]/div[2]/div/div[2]/div[14]/table[2]/tbody/tr[1]/td[9]/span/div/span[1]/span/a/span").click()
    time.sleep(2)
