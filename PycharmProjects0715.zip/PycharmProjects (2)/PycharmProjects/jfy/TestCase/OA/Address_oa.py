import time
from TestCase.OA.Loginpage_oa import login
from selenium.webdriver.common.keys import Keys


def test_address_add():#买家中心-地址管理-新增0709
    wb = login()
    time.sleep(1)
    # 点击买家中心
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[1]/div/div/div/div[3]/div[2]/div[1]/div/a").click()
    # 我的关注
    time.sleep(1)
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[1]/div/div/div/div[3]/div[2]/div[1]/ul/li[3]/a").click()
    time.sleep(2)
    # 点击地址管理
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div[1]/div/div/div[1]/div[6]/div[5]/a").click()
    time.sleep(2)
    # 点击【新增地址】
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div[1]/div/div/div[2]/div/div[2]/div[1]/div[2]/div/div[1]/div/div[1]/div/span/span/button/span").click()
    time.sleep(2)
    #填写【地址名称】
    wb.getElement("xpath",
                  "/html/body/div[1]/div[1]/div/div/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div/div/form/div/section[1]/div/div/div[1]/div/div[2]/div/input").send_keys("新增2")
    # 填写【详细地址】
    wb.getElement("xpath",
                  "/html/body/div[1]/div[1]/div/div/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div/div/form/div/section[1]/div/div/div[3]/div/div[2]/div[1]/input").send_keys(
        "上海市宝山区")
    # 填写【联系人】
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div[1]/div/div/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div/div/form/div/section[1]/div/div/div[4]/div/div[2]/div/input").send_keys(
        "蒋方妍")
    # 填写【手机号】
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div[1]/div/div/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div/div/form/div/section[1]/div/div/div[5]/div/div[2]/div/input").send_keys(
        "15905655568")
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div[1]/div/div/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div/div/form/div/section[2]/div[1]/button").click()
    time.sleep(2)

def test_address_revise():#买家中心-地址管理-修改0709
    wb = login()
    time.sleep(1)
    # 点击买家中心
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[1]/div/div/div/div[3]/div[2]/div[1]/div/a").click()
    # 我的关注
    time.sleep(1)
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[1]/div/div/div/div[3]/div[2]/div[1]/ul/li[3]/a").click()
    time.sleep(2)
    # 点击地址管理
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div[1]/div/div/div[1]/div[6]/div[5]/a").click()
    time.sleep(2)
    # 点击【修改】
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div[1]/div/div/div[2]/div/div[2]/div[1]/div[2]/div/div[2]/div[1]/div[3]/ul/li[3]").click()
    time.sleep(2)
    # 清空手机号
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div[1]/div/div/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div/div/form/div/section[1]/div/div/div[5]/div/div[2]/div/input").send_keys(
        Keys.CONTROL, 'a')
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div[1]/div/div/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div/div/form/div/section[1]/div/div/div[5]/div/div[2]/div/input").send_keys(
        Keys.BACKSPACE)
    # 输入手机号
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div[1]/div/div/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div/div/form/div/section[1]/div/div/div[5]/div/div[2]/div/input").send_keys(
        "13806516654")


def test_address_delete():#买家中心-地址管理-删除0709
    wb = login()
    time.sleep(1)
    # 点击买家中心
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[1]/div/div/div/div[3]/div[2]/div[1]/div/a").click()
    # 我的关注
    time.sleep(1)
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[1]/div/div/div/div[3]/div[2]/div[1]/ul/li[3]/a").click()
    time.sleep(2)
    # 点击地址管理
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div[1]/div/div/div[1]/div[6]/div[5]/a").click()
    time.sleep(2)
    # 点击【删除】
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div[1]/div/div/div[2]/div/div[2]/div[1]/div[2]/div/div[2]/div[1]/div[1]/ul/li[4]/button").click()
    time.sleep(2)
    # 点击【取消】
    wb.getElement("xpath",
                  "/html/body/div[7]/div[3]/button[2]").click()
    time.sleep(2)
