import time
from TestCase.OA.Loginpage_oa import login

def test_basicdata_seller1():#卖家中心-基础资料修改-保存0709
    wb = login()
    time.sleep(1)
    # 点击卖家中心
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[1]/div/div/div/div[3]/div[2]/div[2]/div/a").click()
    # 点击店铺信息
    time.sleep(1)
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[1]/div/div/div/div[3]/div[2]/div[2]/ul/li[3]/a").click()
    time.sleep(2)
    # 点击基础资料
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div[1]/div/div/div[1]/div[6]/div[2]/a").click()
    time.sleep(2)
    # 点击【修改】按钮
    wb.getElement("xpath", "/html/body/div[1]/div[1]/div/div/div[2]/div/div[2]/div[1]/div/div/div/form/div/section[1]/div/div[2]/div/button").click()
    time.sleep(2)
    # 点击【重新上传照片】
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div[1]/div/div/div[2]/div/div[2]/div[1]/div/div/div/form/div/section[1]/div/div/div[3]/div/div[2]/div[2]/div[1]/div/a").click()
    time.sleep(2)
    # 选择图片
    # 点击打开
    # 点击【保存】按钮

def test_basicdata_seller2():#卖家中心-基础资料修改-取消0709
    wb = login()
    time.sleep(1)
    # 点击卖家中心
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[1]/div/div/div/div[3]/div[2]/div[2]/div/a").click()
    # 点击店铺信息
    time.sleep(1)
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[1]/div/div/div/div[3]/div[2]/div[2]/ul/li[3]/a").click()
    time.sleep(2)
    # 点击基础资料
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div[1]/div/div/div[1]/div[6]/div[2]/a").click()
    time.sleep(2)
    # 点击【修改】按钮
    wb.getElement("xpath",
                  "/html/body/div[1]/div[1]/div/div/div[2]/div/div[2]/div[1]/div/div/div/form/div/section[1]/div/div[2]/div/button").click()
    time.sleep(2)
    # 点击【重新上传照片】
    # wb.getElement("xpath",
    #               "//*[@id='b2bShopApp']/div[1]/div/div/div[2]/div/div[2]/div[1]/div/div/div/form/div/section[1]/div/div/div[3]/div/div[2]/div[2]/div[1]/div/a").click()
    # time.sleep(2)
    # 选择图片
    # 点击打开
    # 点击【取消】按钮
    wb.getElement("xpath",
                  "/html/body/div[1]/div[1]/div/div/div[2]/div/div[2]/div[1]/div/div/div/form/div/section[3]/div[2]/button").click()
    time.sleep(2)


def test_basicdata_buyer1():#卖家中心-基础资料修改-保存0709
    wb = login()
    time.sleep(1)
    # 点击买家中心
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[1]/div/div/div/div[3]/div[2]/div[1]/div/a").click()
    # 我的关注
    time.sleep(1)
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[1]/div/div/div/div[3]/div[2]/div[1]/ul/li[3]/a").click()
    time.sleep(2)
    # 点击基础资料
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div[1]/div/div/div[1]/div[5]/div[2]/a").click()
    time.sleep(2)
    # 点击【修改】按钮
    wb.getElement("xpath", "/html/body/div[1]/div[1]/div/div/div[2]/div/div[2]/div[1]/div/div/div/form/div/section[1]/div/div[2]/div/button").click()
    time.sleep(2)
    # 点击【重新上传照片】
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div[1]/div/div/div[2]/div/div[2]/div[1]/div/div/div/form/div/section[1]/div/div/div[3]/div/div[2]/div[2]/div[1]/div/a").click()
    time.sleep(2)
    # 选择图片
    # 点击打开
    # 点击【保存】按钮


def test_basicdata_buyer2():#卖家中心-基础资料修改-保存0709
    wb = login()
    time.sleep(1)
    # 点击买家中心
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[1]/div/div/div/div[3]/div[2]/div[1]/div/a").click()
    # 我的关注
    time.sleep(1)
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[1]/div/div/div/div[3]/div[2]/div[1]/ul/li[3]/a").click()
    time.sleep(2)
    # 点击基础资料
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div[1]/div/div/div[1]/div[5]/div[2]/a").click()
    time.sleep(2)
    # 点击【修改】按钮
    wb.getElement("xpath", "/html/body/div[1]/div[1]/div/div/div[2]/div/div[2]/div[1]/div/div/div/form/div/section[1]/div/div[2]/div/button").click()
    time.sleep(2)
    # 点击【重新上传照片】
    # wb.getElement("xpath", "//*[@id='b2bShopApp']/div[1]/div/div/div[2]/div/div[2]/div[1]/div/div/div/form/div/section[1]/div/div/div[3]/div/div[2]/div[2]/div[1]/div/a").click()
    # time.sleep(2)
    # 选择图片
    # 点击打开
    # 点击【取消】按钮
    wb.getElement("xpath",
                  "/html/body/div[1]/div[1]/div/div/div[2]/div/div[2]/div[1]/div/div/div/form/div/section[3]/div[2]/button").click()
    time.sleep(2)