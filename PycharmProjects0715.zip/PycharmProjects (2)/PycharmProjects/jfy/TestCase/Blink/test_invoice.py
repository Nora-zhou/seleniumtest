import time
from TestCase.Blink.test_loginpage import login

def test_invoice_add():#发票抬头新增0710
    wb = login()
