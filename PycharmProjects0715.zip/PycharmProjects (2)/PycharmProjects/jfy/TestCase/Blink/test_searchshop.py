import time
from TestCase.Blink.test_loginpage import login
from selenium.webdriver.common.keys import Keys


def test_searchshop():
    wb = login()
    time.sleep(2)
    # 搜索店铺
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div/div[2]/div/div/div/div[3]/div/div[1]/div[1]").click()
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div/div[2]/div/div/div/div[3]/div/div[1]/div[1]/div[2]/div[3]").click()
    time.sleep(1.5)
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[2]/div/div/div/div[3]/div/div[1]/div[2]/input").send_keys(
        "下单店铺")  # input shop name
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div/div[2]/div/div/div/div[3]/div/div[2]/input").click()  # click search button
    time.sleep(1)
    # 选择店铺
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div/div[3]/div/div[2]/div/div[4]/div/div/div/div[5]/div[1]/div[5]/div/div[4]/a").click()  # enter shop
    time.sleep(1)
    # 选择商品

    # # add 需求清单
    # wb.SwitchWindow_Two()
    # wb.getElement("xpath",
    #               "//*[@id='b2bShopApp']/div/div[3]/div/div[3]/div[1]/div[1]/div/div/div/div/div[2]/div[2]/div[6]/div[2]/div[1]/div/div[1]").click()  # select 附图片tes
    # wb.getElement("class", "v-number-input--step__input core-input").send_keys("15")
    # wb.getElement("class", "btn-item shop-car primary__color primary__border primary__bg-hover").click()  # click 加入需求清单


def test_searchgoods():
    wb = login()
    time.sleep(2)
    # 搜索商品
    # wb.getElement("xpath", "//*[@id='b2bShopApp']/div[2]/div[2]/div/div/div/div[3]/div/div[1]/div[2]/input").send_keys("spu有图片 64G")  # input goods name
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[2]/div/div/div/div[3]/div/div[1]/div[2]/input").send_keys(
        "spu有图片 64G")  # input goods name
    time.sleep(1)
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div/div[2]/div/div/div/div[3]/div/div[2]/input").click()  # click search button
    time.sleep(1)
    # 选择商品
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div/div[3]/div/div[2]/div/div[4]/div/div/div/div/div[5]/div[1]/div[5]/a/div[1]/div/img").click()  # enter shop
    time.sleep(1)


def test_selectshop():
    wb = login()
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div/div[2]/div/div/div/div[3]/div/div[1]/div[1]").click()
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div/div[2]/div/div/div/div[3]/div/div[1]/div[1]/div[2]/div[3]").click()
    time.sleep(1.5)
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[2]/div/div/div/div[3]/div/div[1]/div[2]/input").send_keys(
        "我的店铺")  # input shop name
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div/div[2]/div/div/div/div[3]/div/div[2]/input").click()  # click search button
    time.sleep(1)
    # 选择店铺
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div/div[3]/div/div[2]/div/div[4]/div/div/div/div[5]/div[1]/div[5]/div/div[4]/a").click()  # enter shop
    wb.SwitchWindow_Two()
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div/div[3]/div/div/div[2]/div[4]/div/div/div/div/div[5]/div[1]/div[5]/a/div[1]/div").click()  # select goods


def test_askprice():
    wb = login()
    time.sleep(3)
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div/div[2]/div/div/div/div[3]/div/div[1]/div[1]").click()
    time.sleep(2)
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div/div[2]/div/div/div/div[3]/div/div[1]/div[1]/div[2]/div[3]").click()
    time.sleep(2)
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[2]/div/div/div/div[3]/div/div[1]/div[2]/input").send_keys(
        "我的店铺")  # input shop name
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div/div[2]/div/div/div/div[3]/div/div[2]/input").click()  # click search button
    time.sleep(1)
    # 选择店铺
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div/div[3]/div/div[2]/div/div[4]/div/div/div/div[5]/div[1]/div[5]/div/div[4]/a").click()  # enter shop
    wb.SwitchWindow_Two()
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div/div[3]/div/div/div[2]/div[4]/div/div/div/div/div[5]/div[1]/div[5]/a/div[1]/div").click()  # select goods

    wb.SwitchWindow_Two()
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div/div[3]/div/div[3]/div[1]/div[1]/div/div/div/div/div[2]/div[2]/div[5]/div[2]/div[1]/div/div[1]").click()  # 选择生产厂商
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div/div[3]/div/div[3]/div[1]/div[1]/div/div/div/div/div[2]/div[3]/div[2]").click()
    time.sleep(3)
    wb.SwitchWindow_Two()

    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div[1]/div/div/div[2]/div/div[2]/div[1]/div/div/div/form/div/section[4]/div/div/div[1]/div/div[2]/div[2]/div[2]/a").click()
    time.sleep(3)
    return wb


def test_askprice_detail():
    # wb = test_askprice()
    # 上面代码是test_askprice
    wb = login()
    time.sleep(5)
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div/div[2]/div/div/div/div[3]/div/div[1]/div[1]").click()
    #
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div/div[2]/div/div/div/div[3]/div/div[1]/div[1]/div[2]/div[3]").click()
    time.sleep(2)
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[2]/div/div/div/div[3]/div/div[1]/div[2]/input").send_keys(
        "我的店铺")  # input shop name
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div/div[2]/div/div/div/div[3]/div/div[2]/input").click()  # click search button
    time.sleep(1)
    # 选择店铺
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div/div[3]/div/div[2]/div/div[4]/div/div/div/div[5]/div[1]/div[5]/div/div[4]/a").click()  # enter shop
    wb.SwitchWindow_Two()
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div/div[3]/div/div/div[2]/div[4]/div/div/div/div/div[5]/div[1]/div[5]/a/div[1]/div").click()  # select goods

    wb.SwitchWindow_Two()
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div/div[3]/div/div[3]/div[1]/div[1]/div/div/div/div/div[2]/div[2]/div[5]/div[2]/div[1]/div/div[1]").click()  # 选择生产厂商
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div/div[3]/div/div[3]/div[1]/div[1]/div/div/div/div/div[2]/div[3]/div[2]").click()
    time.sleep(3)
    wb.SwitchWindow_Two()
    time.sleep(2)
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div[1]/div/div/div[2]/div/div[2]/div[1]/div/div/div/form/div/section[4]/div/div/div[1]/div/div[2]/div[2]/div[2]/a").click()
    # time.sleep(3)
    time.sleep(4)
    wb.SwitchWindow_By_Url("https://blink.qq.com/member/siterfq/index/create?base=salesInformation")
    #选择商品百科
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div[1]/div/div/div[2]/div/div[2]/div[1]/div/div/div/form/div/section[3]/div/div[2]/div[1]/div[14]/table/tbody/tr/td[3]/span/div/div[1]/div[2]/div/div/input").click()
    time.sleep(2)
    wb.getElement("xpath", "/html/body/div[78]/div/div/div[1]/ul/li[1]/div/div/a/div").click()
    time.sleep(2)
    # 修改询价商品数量
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div[1]/div/div/div[2]/div/div[2]/div[1]/div/div/div/form/div/section[3]/div/div[2]/div[1]/div[14]/table/tbody/tr/td[5]/span/div/div[1]/div/input").send_keys(
        Keys.CONTROL, 'a')
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div[1]/div/div/div[2]/div/div[2]/div[1]/div/div/div/form/div/section[3]/div/div[2]/div[1]/div[14]/table/tbody/tr/td[5]/span/div/div[1]/div/input").send_keys(
        Keys.BACKSPACE)
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div[1]/div/div/div[2]/div/div[2]/div[1]/div/div/div/form/div/section[3]/div/div[2]/div[1]/div[14]/table/tbody/tr/td[5]/span/div/div[1]/div/input").send_keys(
        "500")
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div[1]/div/div/div[2]/div/div[2]/div[1]/div/div/div/form/div/section[4]/div/div/div[1]/div/div[2]/div[2]/div[2]/a/label")
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div[1]/div/div/div[2]/div/div[2]/div[1]/div/div/div/form/div/section[8]/div[1]/button").click()

    #修改采购要求收货时间
    wb.ExcuteJs(
        "document.querySelector(\"#b2bShopApp > div.page > div > div > div.content.m-buyer-center > div > div.app-container.name-shoprfq-create > div.m-cooker.content-wrap.v-spinner__container > div > div > div > form > div > section:nth-child(4) > div > div > div:nth-child(1) > div > div.v-form-item__input > div.v-date-picker.m-date-time-picker-el.is-shortcut.is-single > div.v-date-picker__input > a > label\").innerHTML ='2022-07-22'")
    wb.ExcuteJs(
        "document.querySelector(\"#b2bShopApp > div.page > div > div > div.content.m-buyer-center > div > div.app-container.name-shoprfq-create > div.m-cooker.content-wrap.v-spinner__container > div > div > div > form > div > section:nth-child(4) > div > div > div:nth-child(1) > div > div.v-form-item__input > div.m-time-picker-el.v-time-picker > div > span\").innerHTML ='10:15'")

    # p = wb.getElement("xpath",
    #                   "//*[@id='b2bShopApp']/div[1]/div/div/div[2]/div/div[2]/div[1]/div/div/div/form/div/section[4]/div/div/div[1]/div/div[2]/div[2]/div[2]/a/label").get_attribute(
    #     "innerHTML")
    #
    # print(p)

    time.sleep(5)


def test_request_list():
    wb = login()
    time.sleep(4)
    # 搜索店铺
    wb.getElement("xpath", "//*[@id='b2bShopApp']/aside/div[1]/div[1]/div/span").click()
    time.sleep(1)
    wb.getElement("xpath", "//*[@id='b2bShopApp']/aside/div[2]/div[3]/div").click()
    time.sleep(5)
    wb.SwitchWindow_Two()
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div[1]/div/div/div/div/div[2]/div[1]/div[2]/div/div[1]/div[2]/div[1]/div[2]/div[1]/div[9]/table/tbody[2]/tr[1]/td[1]/span/span/label/span").click()
    time.sleep(1)
    # wb.getElement("xpath",
    #               "//*[@id='b2bShopApp']/div[1]/div/div/div/div/div[2]/div[1]/div[2]/div/div[1]/div[2]/div[1]/div[2]/div[1]/div[9]/table/tbody[2]/tr[2]/td[5]/span/span/div/input").click()
    # wb.getElement("xpath",
    #               "//*[@id='b2bShopApp']/div[1]/div/div/div/div/div[2]/div[1]/div[2]/div/div[1]/div[2]/div[1]/div[2]/div[1]/div[9]/table/tbody[2]/tr[2]/td[5]/span/span/div/input").double_click(loc)
    # wb.getElement("xpath",
    #               "//*[@id='b2bShopApp']/div[1]/div/div/div/div/div[2]/div[1]/div[2]/div/div[1]/div[2]/div[1]/div[2]/div[1]/div[9]/table/tbody[2]/tr[2]/td[5]/span/span/div/input").send_keys(
    #     "100")
    # path="//*[@id='b2bShopApp']/div[1]/div/div/div/div/div[2]/div[1]/div[2]/div/div[1]/div[2]/div[1]/div[2]/div[1]/div[9]/table/tbody[2]/tr[2]/td[5]/span/span/div/input"
    # ActionChains(wb).double_click(path).perform()
    # js = "document.querySelector(\"#b2bShopApp > div.page > div > div > div > div > div.app-container.name-shoppingcartsku-list > div.b-row.content-wrap > div:nth-child(2) > div > div.shoppingcart > div:nth-child(2) > div:nth-child(1) > div.shop-content-wrap > div.v-table.shop-content > div.v-table__body > table > tbody:nth-child(4) > tr:nth-child(2) > td.v-table__td.v-table__column11.is-left > span > span > div > label\").value='200';"
    # wb.ExcuteJs(js)
    # 清空数据
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div[1]/div/div/div/div/div[2]/div[1]/div[2]/div/div[1]/div[2]/div[1]/div[2]/div[1]/div[9]/table/tbody[2]/tr[2]/td[5]/span/span/div/input").send_keys(
        Keys.CONTROL, 'a')
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div[1]/div/div/div/div/div[2]/div[1]/div[2]/div/div[1]/div[2]/div[1]/div[2]/div[1]/div[9]/table/tbody[2]/tr[2]/td[5]/span/span/div/input").send_keys(
        Keys.BACKSPACE)
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div[1]/div/div/div/div/div[2]/div[1]/div[2]/div/div[1]/div[2]/div[1]/div[2]/div[1]/div[9]/table/tbody[2]/tr[2]/td[5]/span/span/div/input").send_keys(
        "500")
    time.sleep(5)
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div[1]/div/div/div/div/div[2]/div[1]/div[2]/div/div[1]/div[2]/div[1]/div[2]/div[2]/div/div[1]/span").click()
    time.sleep(10)
