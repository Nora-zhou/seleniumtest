import time
from TestCase.pageUtils import *
from TestCase.test_loginpage_oa import login


def test_searchshop():
    wb = login()
    time.sleep(2)
    # 搜索店铺
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div/div[2]/div/div/div/div[3]/div/div[1]/div[1]").click()
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div/div[2]/div/div/div/div[3]/div/div[1]/div[1]/div[2]/div[3]").click()
    time.sleep(1.5)
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[2]/div/div/div/div[3]/div/div[1]/div[2]/input").send_keys(
        "blackpink")  # input shop name
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div/div[2]/div/div/div/div[3]/div/div[2]/input").click()  # click search button
    time.sleep(1)
    # 选择店铺
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div/div[3]/div/div[2]/div/div[4]/div/div/div/div[5]/div[1]/div[5]/div").click()  # enter shop
    time.sleep(1)
    # 选择商品
    wb.SwitchWindow_Two()
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div/div[3]/div/div/div[2]/div[4]/div/div/div/div/div[5]/div/div[5]/a").click()  # select goods
    time.sleep(2)
    # # add 需求清单
    # wb.SwitchWindow_Two()
    # wb.getElement("xpath",
    #               "//*[@id='b2bShopApp']/div/div[3]/div/div[3]/div[1]/div[1]/div/div/div/div/div[2]/div[2]/div[6]/div[2]/div[1]/div/div[1]").click()  # select 附图片tes
    # wb.getElement("class", "v-number-input--step__input core-input").send_keys("15")
    # wb.getElement("class", "btn-item shop-car primary__color primary__border primary__bg-hover").click()  # click 加入需求清单


def test_selectgoods():
    wb = login()
    time.sleep(2)
    # 搜索店铺
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div/div[2]/div/div/div/div[3]/div/div[1]/div[1]").click()
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div/div[2]/div/div/div/div[3]/div/div[1]/div[1]/div[2]/div[3]").click()
    time.sleep(1.5)
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[2]/div/div/div/div[3]/div/div[1]/div[2]/input").send_keys(
        "blackpink")  # input shop name
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div/div[2]/div/div/div/div[3]/div/div[2]/input").click()  # click search button
    time.sleep(1)
    # 选择店铺
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div/div[3]/div/div[2]/div/div[4]/div/div/div/div[5]/div[1]/div[5]/div").click()  # enter shop
    time.sleep(1)


def test_askprice():#点击询价
    wb = login()
    time.sleep(3)
    # 搜索店铺
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div/div[2]/div/div/div/div[3]/div/div[1]/div[1]").click()
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div/div[2]/div/div/div/div[3]/div/div[1]/div[1]/div[2]/div[3]").click()
    time.sleep(1.5)
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[2]/div/div/div/div[3]/div/div[1]/div[2]/input").send_keys(
        "blackpink")  # input shop name
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div/div[2]/div/div/div/div[3]/div/div[2]/input").click()  # click search button
    time.sleep(1)
    # 选择店铺
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div/div[3]/div/div[2]/div/div[4]/div/div/div/div[5]/div[1]/div[5]/div").click()  # enter shop
    time.sleep(1)
    # 选择商品
    wb.SwitchWindow_Two()
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div/div[3]/div/div/div[2]/div[4]/div/div/div/div/div[5]/div/div[5]/a").click()  # select goods

    wb.SwitchWindow_Two()
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div/div[3]/div/div[3]/div[1]/div[1]/div/div/div/div/div[2]/div[2]/div[5]/div[2]/div[2]/div").click()  # 选择容量
    #wb.getElement("xpath","//*[@id='b2bShopApp']/div/div[3]/div/div[3]/div[1]/div[1]/div/div/div/div/div[2]/div[2]/div[6]/div[2]/span[1]/div[1]/input").clear()
    time.sleep(2)
    wb.getElement("xpath","//*[@id='b2bShopApp']/div/div[3]/div/div[3]/div[1]/div[1]/div/div/div/div/div[2]/div[2]/div[6]/div[2]/span[1]/div[1]/input").send_keys("00")
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[3]/div/div[3]/div[1]/div[1]/div/div/div/div/div[2]/div[3]/div[2]").click()
