import time
from TestCase.pageUtils import *
from TestCase.test_loginpage import login


def test_searchshop():
    wb = login()
    time.sleep(2)
    # 搜索店铺
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div/div[2]/div/div/div/div[3]/div/div[1]/div[1]").click()
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div/div[2]/div/div/div/div[3]/div/div[1]/div[1]/div[2]/div[3]").click()
    time.sleep(1.5)
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[2]/div/div/div/div[3]/div/div[1]/div[2]/input").send_keys(
        "下单店铺")  # input shop name
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div/div[2]/div/div/div/div[3]/div/div[2]/input").click()  # click search button
    time.sleep(1)
    # 选择店铺
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div/div[3]/div/div[2]/div/div[4]/div/div/div/div[5]/div[1]/div[5]/div/div[4]/a").click()  # enter shop
    time.sleep(1)
    # 选择商品

    # # add 需求清单
    # wb.SwitchWindow_Two()
    # wb.getElement("xpath",
    #               "//*[@id='b2bShopApp']/div/div[3]/div/div[3]/div[1]/div[1]/div/div/div/div/div[2]/div[2]/div[6]/div[2]/div[1]/div/div[1]").click()  # select 附图片tes
    # wb.getElement("class", "v-number-input--step__input core-input").send_keys("15")
    # wb.getElement("class", "btn-item shop-car primary__color primary__border primary__bg-hover").click()  # click 加入需求清单


def test_searchgoods():
    wb = login()
    time.sleep(2)
    # 搜索商品
    # wb.getElement("xpath", "//*[@id='b2bShopApp']/div[2]/div[2]/div/div/div/div[3]/div/div[1]/div[2]/input").send_keys("spu有图片 64G")  # input goods name
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[2]/div/div/div/div[3]/div/div[1]/div[2]/input").send_keys(
        "spu有图片 64G")  # input goods name
    time.sleep(1)
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div/div[2]/div/div/div/div[3]/div/div[2]/input").click()  # click search button
    time.sleep(1)
    # 选择商品
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div/div[3]/div/div[2]/div/div[4]/div/div/div/div/div[5]/div[1]/div[5]/a/div[1]/div/img").click()  # enter shop
    time.sleep(1)


def test_selectshop():
    wb = login()
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div/div[2]/div/div/div/div[3]/div/div[1]/div[1]").click()
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div/div[2]/div/div/div/div[3]/div/div[1]/div[1]/div[2]/div[3]").click()
    time.sleep(1.5)
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[2]/div/div/div/div[3]/div/div[1]/div[2]/input").send_keys(
        "我的店铺")  # input shop name
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div/div[2]/div/div/div/div[3]/div/div[2]/input").click()  # click search button
    time.sleep(1)
    # 选择店铺
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div/div[3]/div/div[2]/div/div[4]/div/div/div/div[5]/div[1]/div[5]/div/div[4]/a").click()  # enter shop
    wb.SwitchWindow_Two()
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div/div[3]/div/div/div[2]/div[4]/div/div/div/div/div[5]/div[1]/div[5]/a/div[1]/div").click()  # select goods


def test_askprice():
    wb = login()
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div/div[2]/div/div/div/div[3]/div/div[1]/div[1]").click()
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div/div[2]/div/div/div/div[3]/div/div[1]/div[1]/div[2]/div[3]").click()
    time.sleep(1.5)
    wb.getElement("xpath", "//*[@id='b2bShopApp']/div/div[2]/div/div/div/div[3]/div/div[1]/div[2]/input").send_keys(
        "我的店铺")  # input shop name
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div/div[2]/div/div/div/div[3]/div/div[2]/input").click()  # click search button
    time.sleep(1)
    # 选择店铺
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div/div[3]/div/div[2]/div/div[4]/div/div/div/div[5]/div[1]/div[5]/div/div[4]/a").click()  # enter shop
    wb.SwitchWindow_Two()
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div/div[3]/div/div/div[2]/div[4]/div/div/div/div/div[5]/div[1]/div[5]/a/div[1]/div").click()  # select goods

    wb.SwitchWindow_Two()
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div/div[3]/div/div[3]/div[1]/div[1]/div/div/div/div/div[2]/div[2]/div[5]/div[2]/div[1]/div/div[1]").click()  # 选择生产厂商
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div/div[3]/div/div[3]/div[1]/div[1]/div/div/div/div/div[2]/div[3]/div[2]").click()
    time.sleep(3)
    wb.SwitchWindow_Two()
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div[1]/div/div/div[2]/div/div[2]/div[1]/div/div/div/form/div/section[4]/div/div/div[1]/div/div[2]/div[2]/div[2]/a").click()
    time.sleep(3)
    return wb


def test_askprice_detail():
    wb = test_askprice()
    # 上面代码是test_askprice
    time.sleep(2)
    wb.SwitchWindow_By_Url("https://blink.qq.com/member/siterfq/index/create?base=salesInformation")
    # 选择商品百科
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div[1]/div/div/div[2]/div/div[2]/div[1]/div/div/div/form/div/section[3]/div/div[2]/div[1]/div[14]/table/tbody/tr/td[3]/span/div/div[1]/div[2]/div/div/input").click()
    time.sleep(1)
    wb.getElement("xpath", "/html/body/div[96]/div/div/div[1]/ul/li[2]/div/div/a/div/div[1]").click()
    # time.sleep(2)
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div[1]/div/div/div[2]/div/div[2]/div[1]/div/div/div/form/div/section[4]/div/div/div[1]/div/div[2]/div[2]/div[2]/a/label")
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div[1]/div/div/div[2]/div/div[2]/div[1]/div/div/div/form/div/section[8]/div[1]/button").click()


def test_request_list():
    wb = login()
    time.sleep(2)
    # 搜索店铺
    wb.getElement("xpath", "//*[@id='b2bShopApp']/aside/div[1]/div[1]/div/span").click()
    time.sleep(1)
    wb.getElement("xpath", "//*[@id='b2bShopApp']/aside/div[2]/div[3]/div").click()
    time.sleep(5)
    wb.SwitchWindow_Two()
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div[1]/div/div/div/div/div[2]/div[1]/div[2]/div/div[1]/div[2]/div[1]/div[2]/div[1]/div[9]/table/tbody[2]/tr[1]/td[1]/span/span/label/span").click()
    time.sleep(1)
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div[1]/div/div/div/div/div[2]/div[1]/div[2]/div/div[1]/div[2]/div[1]/div[2]/div[1]/div[9]/table/tbody[2]/tr[2]/td[5]/span/span/div/input").send_keys(
        "100")
    wb.getElement("xpath",
                  "//*[@id='b2bShopApp']/div[1]/div/div/div/div/div[2]/div[1]/div[2]/div/div[1]/div[2]/div[1]/div[2]/div[2]/div/div[1]/span").click()
    time.sleep(3)
